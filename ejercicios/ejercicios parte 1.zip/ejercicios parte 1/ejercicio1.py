'''
Ejercicio 1: Operadores Aritméticos

Problema: Escribe un programa que solicite al usuario dos números y 
realice las operaciones de suma, resta, multiplicación, división y módulo.

'''


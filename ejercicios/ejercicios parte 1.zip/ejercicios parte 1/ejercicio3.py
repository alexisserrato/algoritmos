'''
Problema: Escribe un programa que solicite un número al usuario y lo incremente en 5 unidades y 
luego lo decremente en 3.
'''

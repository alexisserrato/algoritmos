'''
Problema: Escribe un programa que solicite la base y la altura de un rectángulo y calcule su área.
'''
